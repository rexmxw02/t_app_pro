# t_app_pro

高级版仿税务服务 App 演示项目。

## 功能
- 手机号验证码登录界面
- 首页收入总览
- 收入纳税明细
- 收入详情
- 搜索筛选
- 图表统计
- 用户中心
- GitHub Actions 自动构建 APK

## 自动生成 APK
代码推送到 GitHub 后，进入：

Actions -> Build Android APK -> 最新一次运行 -> Artifacts

下载 `t-app-pro-release-apk`，里面就是 `app-release.apk`。
