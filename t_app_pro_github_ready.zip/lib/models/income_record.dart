class IncomeRecord {
  final String month;
  final String type;
  final String subType;
  final String company;
  final double income;
  final double tax;
  final double socialInsurance;
  final double housingFund;
  const IncomeRecord({required this.month, required this.type, required this.subType, required this.company, required this.income, required this.tax, required this.socialInsurance, required this.housingFund});
}
