import 'package:flutter/material.dart';
import 'pages/login_page.dart';

void main() {
  runApp(const TAppPro());
}

class TAppPro extends StatefulWidget {
  const TAppPro({super.key});
  @override
  State<TAppPro> createState() => _TAppProState();
}

class _TAppProState extends State<TAppPro> {
  bool darkMode = false;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '个人税务服务',
      debugShowCheckedModeBanner: false,
      themeMode: darkMode ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(colorSchemeSeed: const Color(0xff1677ff), useMaterial3: true, scaffoldBackgroundColor: const Color(0xfff5f6f9)),
      darkTheme: ThemeData(colorSchemeSeed: const Color(0xff1677ff), brightness: Brightness.dark, useMaterial3: true),
      home: LoginPage(onToggleTheme: () => setState(() => darkMode = !darkMode)),
    );
  }
}
