import 'package:flutter/material.dart';
import '../services/mock_data_service.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override Widget build(BuildContext context) {
    final totalIncome = MockDataService.records.fold<double>(0, (s,e)=>s+e.income);
    final totalTax = MockDataService.records.fold<double>(0, (s,e)=>s+e.tax);
    return Scaffold(appBar: AppBar(title: const Text('首页')), body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors:[Color(0xff1677ff), Color(0xff55a6ff)]), borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('年度收入总览', style: TextStyle(color: Colors.white70)), const SizedBox(height:10), Text('¥${totalIncome.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height:8), Text('已申报税额 ¥${totalTax.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white)),
      ])),
      const SizedBox(height:18),
      GridView.count(shrinkWrap:true, crossAxisCount:2, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing:12, crossAxisSpacing:12, children: const [
        _QuickCard(icon: Icons.receipt_long, title: '收入明细'), _QuickCard(icon: Icons.calculate_outlined, title: '税额计算'), _QuickCard(icon: Icons.report_problem_outlined, title: '申诉管理'), _QuickCard(icon: Icons.file_download_outlined, title: '证明下载'),
      ]),
    ]));
  }
}
class _QuickCard extends StatelessWidget { final IconData icon; final String title; const _QuickCard({required this.icon, required this.title}); @override Widget build(BuildContext context) => Card(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children:[Icon(icon, color: const Color(0xff1677ff), size:34), const SizedBox(height:10), Text(title, style: const TextStyle(fontWeight: FontWeight.w600))]))); }
