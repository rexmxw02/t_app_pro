import '../models/income_record.dart';

class MockDataService {
  static const records = [
    IncomeRecord(month: '2025-12', type: '工资薪金', subType: '正常工资薪金', company: '优视科技（中国）有限公司', income: 34749.63, tax: 4033.25, socialInsurance: 2680, housingFund: 2100),
    IncomeRecord(month: '2025-11', type: '工资薪金', subType: '正常工资薪金', company: '优视科技（中国）有限公司', income: 32600, tax: 3603.32, socialInsurance: 2680, housingFund: 2100),
    IncomeRecord(month: '2025-10', type: '工资薪金', subType: '正常工资薪金', company: '优视科技（中国）有限公司', income: 32550, tax: 3523.57, socialInsurance: 2680, housingFund: 2100),
    IncomeRecord(month: '2025-09', type: '工资薪金', subType: '正常工资薪金', company: '优视科技（中国）有限公司', income: 32480, tax: 3498.20, socialInsurance: 2680, housingFund: 2100),
    IncomeRecord(month: '2025-08', type: '工资薪金', subType: '正常工资薪金', company: '优视科技（中国）有限公司', income: 31800, tax: 3312.80, socialInsurance: 2680, housingFund: 2100),
  ];
}
