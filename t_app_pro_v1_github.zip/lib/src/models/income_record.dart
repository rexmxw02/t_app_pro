class IncomeRecord {
  final String month, type, subType, company;
  final double income, tax, insurance, fund;
  const IncomeRecord({required this.month, required this.type, required this.subType, required this.company, required this.income, required this.tax, required this.insurance, required this.fund});
  double get afterTax => income - tax - insurance - fund;
}
