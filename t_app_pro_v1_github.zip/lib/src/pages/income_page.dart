import 'package:flutter/material.dart';
import '../models/income_record.dart';
import '../services/mock_data.dart';
import 'income_detail_page.dart';

class IncomePage extends StatefulWidget{const IncomePage({super.key});@override State<IncomePage> createState()=>_IncomePageState();}
class _IncomePageState extends State<IncomePage>{String q='';
 @override Widget build(BuildContext context){
  final records=MockData.records.where((e)=>e.month.contains(q)||e.company.contains(q)||e.type.contains(q)).toList();
  final ti=records.fold<double>(0,(s,e)=>s+e.income), tt=records.fold<double>(0,(s,e)=>s+e.tax);
  return Scaffold(appBar:AppBar(title:const Text('收入纳税明细'),actions:[TextButton(onPressed:(){}, child:const Text('批量申诉'))]),body:Column(children:[
   Container(color:Theme.of(context).cardColor,padding:const EdgeInsets.all(16),child:Column(children:[_Sum('收入合计','${ti.toStringAsFixed(2)}元'),const Divider(),_Sum('已申报税额合计','${tt.toStringAsFixed(2)}元'),const SizedBox(height:12),TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(hintText:'搜索月份、公司、收入类型',prefixIcon:const Icon(Icons.search),filled:true,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none)))])),
   Expanded(child:ListView.builder(itemCount:records.length,itemBuilder:(_,i)=>_IncomeCard(records[i]))) ]));}}
class _Sum extends StatelessWidget{final String a,b;const _Sum(this.a,this.b);@override Widget build(BuildContext context)=>Row(children:[Text(a,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),const Spacer(),Text(b,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))]);}
class _IncomeCard extends StatelessWidget{final IncomeRecord r;const _IncomeCard(this.r);@override Widget build(BuildContext context)=>Card(margin:const EdgeInsets.fromLTRB(12,10,12,4),child:ListTile(title:Row(children:[Text(r.type,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w600)),const Spacer(),Text(r.month)]),subtitle:Padding(padding:const EdgeInsets.only(top:10),child:Text('所得项目小类：${r.subType}
扣缴义务人：${r.company}
收入：${r.income.toStringAsFixed(2)}元
已申报税额：${r.tax.toStringAsFixed(2)}元')),trailing:const Icon(Icons.arrow_forward_ios,size:18),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>IncomeDetailPage(record:r)))));}
