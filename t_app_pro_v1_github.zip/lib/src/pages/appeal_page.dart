import 'package:flutter/material.dart';
class AppealPage extends StatelessWidget{const AppealPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('申诉管理')),body:ListView(padding:const EdgeInsets.all(16),children:[const Card(child:ListTile(leading:Icon(Icons.edit_note),title:Text('新建申诉'),subtitle:Text('对收入记录发起核实申请'))),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:const[Text('申诉流程',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),SizedBox(height:10),Text('1. 选择收入记录
2. 填写申诉原因
3. 上传证明材料
4. 等待处理结果')])))]));}
